from app.services.activity_service import generate_activities
from app.services.validator_service import validate_activity

from app.storage.activity_repository import (
    create_activity,
    mark_activity_regenerated
)


def regenerate_activity(
    old_activity,
    context,
    topic
):

    activities = generate_activities(
        context,
        topic
    )


    for new_activity in activities.activities:


        # evita gerar igual

        if (
            new_activity.question.strip()
            ==
            old_activity["question"].strip()
        ):
            continue



        validation = validate_activity(
            new_activity
        )


        if validation.approved:


            # marca antiga

            mark_activity_regenerated(
                old_activity["id"]
            )


            # salva nova

            new_id = create_activity(

                topic_id=old_activity["topic_id"],

                topic=old_activity["topic"],

                learning_objective=new_activity.learning_objective,

                activity_type=new_activity.type,

                difficulty=new_activity.difficulty,

                cognitive_skill=new_activity.cognitive_skill,

                learning_dimension=new_activity.learning_dimension,

                question=new_activity.question,

                options=new_activity.options,

                correct_answer=new_activity.correct_answer,

                explanation=new_activity.explanation,

                hints=new_activity.hints,

                review_status="pending",

                validation_score=validation.score,

                validation_warnings=validation.warnings

            )


            return new_id



    raise Exception(
        "Não foi possível gerar nova questão"
    )